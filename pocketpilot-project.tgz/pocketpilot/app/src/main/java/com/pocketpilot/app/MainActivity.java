package com.pocketpilot.app;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private static final int PRIMARY = Color.rgb(91,95,239);
    private static final int PRIMARY_DARK = Color.rgb(73,77,223);
    private static final int GREEN = Color.rgb(21,184,151);
    private static final int CANVAS = Color.rgb(246,247,251);
    private static final int SURFACE = Color.WHITE;
    private static final int INK = Color.rgb(23,32,51);
    private static final int MUTED = Color.rgb(108,116,134);
    private static final int BORDER = Color.rgb(230,233,240);
    private static final int PALE_GREEN = Color.rgb(232,248,244);
    private static final int PALE_PURPLE = Color.rgb(236,236,255);
    private static final String PREFS = "pocketpilot";
    private static final String CHANNEL = "focus";

    private FrameLayout root;
    private SharedPreferences prefs;
    private CountDownTimer countDownTimer;
    private long remainingMs = 25 * 60 * 1000L;
    private boolean timerRunning = false;
    private CircleTimerView circleTimerView;
    private TextView timerText;
    private LinearLayout focusScreen;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(CANVAS);
        getWindow().setNavigationBarColor(CANVAS);
        if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
        root = new FrameLayout(this);
        root.setBackgroundColor(CANVAS);
        setContentView(root);
        showSplash();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable bg(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp)); return g;
    }
    private GradientDrawable bgStroke(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = bg(color, radiusDp); g.setStroke(dp(1), strokeColor); return g;
    }
    private TextView tv(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(sp); t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create("sans", bold?Typeface.BOLD:Typeface.NORMAL)); t.setIncludeFontPadding(false); return t;
    }
    private LinearLayout vbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout hbox() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private Space space(int h) { Space s = new Space(this); s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return s; }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }

    private Button button(String label, int color, int textColor) {
        Button b = new Button(this); b.setText(label); b.setTextSize(15); b.setTextColor(textColor); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(bg(color,18)); b.setStateListAnimator(null); b.setMinHeight(0); b.setMinWidth(0); return b;
    }
    private TextView pill(String label, int fill, int color) {
        TextView p = tv(label, 12, color, true); p.setGravity(Gravity.CENTER); p.setBackground(bg(fill, 20)); pad(p,14,8,14,8); return p;
    }
    private LinearLayout card() { LinearLayout l=vbox(); l.setBackground(bgStroke(SURFACE,22,BORDER)); l.setElevation(dp(2)); pad(l,20,18,20,18); return l; }

    private ScrollView shell(LinearLayout body) {
        ScrollView s = new ScrollView(this); s.setFillViewport(true); s.setBackgroundColor(CANVAS); s.addView(body,new ScrollView.LayoutParams(-1,-2)); return s;
    }

    private void replace(View next, boolean forward) {
        if (root.getChildCount()==0) { root.addView(next,new FrameLayout.LayoutParams(-1,-1)); return; }
        View old = root.getChildAt(root.getChildCount()-1);
        next.setAlpha(0f); next.setTranslationX(forward?dp(24):-dp(24)); root.addView(next,new FrameLayout.LayoutParams(-1,-1));
        next.animate().alpha(1f).translationX(0).setDuration(320).setInterpolator(new DecelerateInterpolator()).start();
        old.animate().alpha(0f).translationX(forward?-dp(22):dp(22)).setDuration(260).setListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator a){root.removeView(old);}}).start();
    }

    private void showSplash() {
        FrameLayout s = new FrameLayout(this); s.setBackgroundColor(PRIMARY);
        TextView glow = tv("",1,Color.WHITE,false); glow.setBackground(bg(Color.argb(32,255,255,255),100));
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(190),dp(190),Gravity.CENTER); gp.topMargin=-dp(150); s.addView(glow,gp);
        TextView logo = tv("PP",28,Color.WHITE,true); logo.setGravity(Gravity.CENTER); logo.setBackground(bg(Color.argb(55,255,255,255),24));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(72),dp(72),Gravity.CENTER); lp.topMargin=-dp(140); s.addView(logo,lp);
        TextView title=tv("PocketPilot",30,Color.WHITE,true); title.setGravity(Gravity.CENTER); FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(50),Gravity.CENTER); tp.topMargin=dp(20); tp.leftMargin=dp(40);tp.rightMargin=dp(40);s.addView(title,tp);
        TextView tag=tv("Plan. Focus. Finish calmly.",14,Color.rgb(230,231,255),false); tag.setGravity(Gravity.CENTER); FrameLayout.LayoutParams tg=new FrameLayout.LayoutParams(-1,dp(40),Gravity.CENTER); tg.topMargin=dp(85);tg.leftMargin=dp(40);tg.rightMargin=dp(40);s.addView(tag,tg);
        root.addView(s,new FrameLayout.LayoutParams(-1,-1));
        logo.setScaleX(.65f);logo.setScaleY(.65f);glow.setScaleX(.55f);glow.setScaleY(.55f);title.setAlpha(0);tag.setAlpha(0);
        logo.animate().scaleX(1.15f).scaleY(1.15f).setDuration(650).setInterpolator(new AccelerateDecelerateInterpolator()).withEndAction(()->logo.animate().scaleX(1).scaleY(1).setDuration(250).start()).start();
        glow.animate().scaleX(1.65f).scaleY(1.65f).alpha(.6f).setDuration(950).start();
        title.animate().alpha(1).setStartDelay(380).setDuration(500).start(); tag.animate().alpha(1).setStartDelay(560).setDuration(500).start();
        s.postDelayed(() -> { if (prefs.getBoolean("onboarded",false)) replace(buildHome(),true); else replace(buildOnboarding(),true); }, 1650);
    }

    private View buildOnboarding() {
        LinearLayout body=vbox(); pad(body,24,36,24,30); body.setBackgroundColor(CANVAS);
        LinearLayout hero=card(); hero.setBackground(bg(Color.rgb(239,240,255),30)); hero.setMinimumHeight(dp(285));
        TextView mini1=pill("Top 3 for today",Color.WHITE,INK); mini1.setTextSize(15); mini1.setGravity(Gravity.CENTER); hero.addView(mini1,new LinearLayout.LayoutParams(dp(150),dp(62)));
        Space sp=new Space(this); hero.addView(sp,new LinearLayout.LayoutParams(1,dp(48)));
        TextView mini2=pill("25 min deep focus",Color.WHITE,INK); mini2.setTextSize(15); hero.addView(mini2,new LinearLayout.LayoutParams(dp(170),dp(62)));
        body.addView(hero,new LinearLayout.LayoutParams(-1,dp(286))); body.addView(space(42));
        body.addView(tv("Make today feel\nlighter.",32,INK,true)); body.addView(space(20));
        TextView p=tv("PocketPilot helps you choose what matters, focus on it, and close the day without carrying everything in your head.",15,MUTED,false); p.setLineSpacing(dp(5),1); body.addView(p); body.addView(space(70));
        Button go=button("Get started",PRIMARY,Color.WHITE); body.addView(go,new LinearLayout.LayoutParams(-1,dp(56))); go.setOnClickListener(v->replace(buildDailySetup(),true));
        body.addView(space(18)); TextView foot=tv("No account needed • Your data stays on this phone",12,MUTED,false); foot.setGravity(Gravity.CENTER); body.addView(foot);
        return shell(body);
    }

    private View labeledTaskInput(String n, String value, String sub, int fill, EditText[] holder, int idx) {
        LinearLayout row=hbox(); row.setGravity(Gravity.CENTER_VERTICAL); row.setBackground(bgStroke(SURFACE,18,BORDER)); pad(row,14,12,14,12);
        TextView badge=tv(n,14,PRIMARY,true); badge.setGravity(Gravity.CENTER); badge.setBackground(bg(fill,12)); row.addView(badge,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout right=vbox(); pad(right,14,0,0,0); EditText e=new EditText(this); e.setText(value); e.setTextSize(15);e.setTextColor(INK);e.setSingleLine(true);e.setBackgroundColor(Color.TRANSPARENT);e.setPadding(0,0,0,0); right.addView(e,new LinearLayout.LayoutParams(-1,dp(30))); right.addView(tv(sub,11,MUTED,false)); row.addView(right,new LinearLayout.LayoutParams(0,dp(48),1)); holder[idx]=e; return row;
    }

    private View buildDailySetup() {
        LinearLayout body=vbox(); pad(body,24,34,24,28); body.setBackgroundColor(CANVAS);
        body.addView(tv("Good morning, Victor",26,INK,true)); body.addView(tv("What would make today a win?",14,MUTED,false)); body.addView(space(40)); body.addView(tv("Choose your top 3",15,INK,true)); body.addView(space(14));
        EditText[] e=new EditText[3];
        String p1=prefs.getString("p1","Finish scholarship draft"),p2=prefs.getString("p2","Review app prototype"),p3=prefs.getString("p3","30 min exercise");
        body.addView(labeledTaskInput("1",p1,"High impact",Color.rgb(239,240,255),e,0),new LinearLayout.LayoutParams(-1,dp(72))); body.addView(space(12));
        body.addView(labeledTaskInput("2",p2,"45 min",Color.rgb(239,240,255),e,1),new LinearLayout.LayoutParams(-1,dp(72))); body.addView(space(12));
        body.addView(labeledTaskInput("3",p3,"Personal",Color.rgb(239,240,255),e,2),new LinearLayout.LayoutParams(-1,dp(72))); body.addView(space(28));
        body.addView(tv("Energy today",15,INK,true)); body.addView(space(12)); LinearLayout energy=hbox(); energy.setGravity(Gravity.CENTER); String[] es={"Low","Steady","High"}; for(int i=0;i<3;i++){TextView c=pill(es[i],i==1?PRIMARY:Color.WHITE,i==1?Color.WHITE:MUTED);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(40),1);if(i>0)cp.leftMargin=dp(8);energy.addView(c,cp);}body.addView(energy);
        body.addView(space(26)); body.addView(tv("Available focus time",15,INK,true)); body.addView(space(10)); LinearLayout focus=card(); focus.setOrientation(LinearLayout.HORIZONTAL); focus.setGravity(Gravity.CENTER_VERTICAL);focus.addView(tv("2 h 30 min",18,INK,true),new LinearLayout.LayoutParams(0,dp(40),1));focus.addView(tv("Edit",13,PRIMARY,true),new LinearLayout.LayoutParams(dp(50),dp(40)));body.addView(focus,new LinearLayout.LayoutParams(-1,dp(64)));
        body.addView(space(30)); Button go=button("Build my day",PRIMARY,Color.WHITE); body.addView(go,new LinearLayout.LayoutParams(-1,dp(56))); go.setOnClickListener(v->{prefs.edit().putString("p1",e[0].getText().toString().trim()).putString("p2",e[1].getText().toString().trim()).putString("p3",e[2].getText().toString().trim()).putBoolean("onboarded",true).apply();replace(buildHome(),true);});
        return shell(body);
    }

    private LinearLayout progressCard() {
        LinearLayout c=vbox(); c.setBackground(bg(PRIMARY,24)); pad(c,20,18,20,18);
        int completed=completedCount(); c.addView(tv("DAY PROGRESS",11,Color.rgb(217,218,255),true)); c.addView(space(8)); c.addView(tv(completed+" of 3 priorities",23,Color.WHITE,true)); c.addView(space(4)); c.addView(tv(completed>=2?"You’re ahead of your planned pace.":"One focused block can change the day.",13,Color.rgb(236,236,255),false)); c.addView(space(28));
        FrameLayout bar=new FrameLayout(this); TextView track=tv("",1,Color.TRANSPARENT,false);track.setBackground(bg(Color.rgb(119,122,242),4));bar.addView(track,new FrameLayout.LayoutParams(-1,dp(8)));TextView fill=tv("",1,Color.TRANSPARENT,false);fill.setBackground(bg(Color.WHITE,4));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(0,dp(8));fp.width=dp((float)(292*Math.max(0.06,completed/3.0)));bar.addView(fill,fp);c.addView(bar,new LinearLayout.LayoutParams(-1,dp(8))); return c;
    }

    private View buildHome() {
        LinearLayout body=vbox(); pad(body,24,28,24,18); body.setBackgroundColor(CANVAS);
        LocalDate now=LocalDate.now(); String date=now.format(DateTimeFormatter.ofPattern("EEEE • d MMM", Locale.ENGLISH));
        body.addView(tv("Today",28,INK,true)); body.addView(tv(date,13,MUTED,false)); body.addView(space(22)); body.addView(progressCard(),new LinearLayout.LayoutParams(-1,dp(176))); body.addView(space(30)); body.addView(tv("Next up",14,INK,true)); body.addView(space(10));
        LinearLayout next=card(); next.setOrientation(LinearLayout.HORIZONTAL); next.setGravity(Gravity.CENTER_VERTICAL);
        TextView play=tv("▶",18,GREEN,true);play.setGravity(Gravity.CENTER);play.setBackground(bg(PALE_GREEN,16));next.addView(play,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout copy=vbox();pad(copy,16,0,0,0);copy.addView(tv(prefs.getString("p2","Review app prototype"),15,INK,true));copy.addView(tv("Focus block • 25 min",12,MUTED,false));next.addView(copy,new LinearLayout.LayoutParams(0,dp(58),1));TextView start=tv("Start",12,PRIMARY,true);start.setGravity(Gravity.CENTER);next.addView(start,new LinearLayout.LayoutParams(dp(54),dp(42)));next.setOnClickListener(v->replace(buildTaskDetail(2),true));body.addView(next,new LinearLayout.LayoutParams(-1,dp(104)));
        body.addView(space(30)); body.addView(tv("Your priorities",14,INK,true)); body.addView(space(8));
        addPriorityRow(body,1,prefs.getString("p1","Finish scholarship draft"),prefs.getBoolean("done1",true)); addPriorityRow(body,2,prefs.getString("p2","Review app prototype"),prefs.getBoolean("done2",false)); addPriorityRow(body,3,prefs.getString("p3","30 min exercise"),prefs.getBoolean("done3",false));
        String extra=prefs.getString("extra",""); if(!extra.isEmpty()){body.addView(space(4)); TextView ex=tv("＋  "+extra,13,INK,false);pad(ex,4,10,4,10);body.addView(ex);}
        body.addView(space(18)); Button close=button("Close today",Color.WHITE,PRIMARY);close.setBackground(bgStroke(Color.WHITE,18,BORDER));body.addView(close,new LinearLayout.LayoutParams(-1,dp(48)));close.setOnClickListener(v->replace(buildReflection(),true)); body.addView(space(18));
        LinearLayout nav=bottomNav(0);body.addView(nav,new LinearLayout.LayoutParams(-1,dp(72)));
        FrameLayout wrap=new FrameLayout(this);wrap.addView(shell(body),new FrameLayout.LayoutParams(-1,-1));Button fab=button("+",Color.rgb(17,24,39),Color.WHITE);fab.setTextSize(28);FrameLayout.LayoutParams fbp=new FrameLayout.LayoutParams(dp(60),dp(60),Gravity.BOTTOM|Gravity.END);fbp.setMargins(0,0,dp(24),dp(94));wrap.addView(fab,fbp);fab.setElevation(dp(10));fab.setOnClickListener(v->showQuickAdd());return wrap;
    }

    private void addPriorityRow(LinearLayout body,int n,String label,boolean done) {
        LinearLayout r=hbox();r.setGravity(Gravity.CENTER_VERTICAL);pad(r,4,9,4,9);TextView num=tv(done?"✓":String.valueOf(n),14,done?GREEN:PRIMARY,true);num.setGravity(Gravity.CENTER);r.addView(num,new LinearLayout.LayoutParams(dp(30),dp(34)));TextView lab=tv(label,13,done?MUTED:INK,!done);r.addView(lab,new LinearLayout.LayoutParams(0,dp(34),1));r.setOnClickListener(v->{prefs.edit().putBoolean("done"+n,!done).apply();replace(buildHome(),false);});body.addView(r);
    }

    private LinearLayout bottomNav(int selected) {
        LinearLayout nav=hbox();nav.setGravity(Gravity.CENTER);nav.setBackground(bgStroke(Color.WHITE,22,BORDER));String[] labels={"⌂\nHome","✓\nTasks","◷\nFocus","◎\nProfile"};for(int i=0;i<4;i++){TextView n=tv(labels[i],11,i==selected?PRIMARY:MUTED,true);n.setGravity(Gravity.CENTER);n.setLineSpacing(dp(2),1);final int ix=i;nav.addView(n,new LinearLayout.LayoutParams(0,-1,1));n.setOnClickListener(v->{if(ix==0)replace(buildHome(),false);else if(ix==1)replace(buildTasks(),true);else if(ix==2)startFocus();else replace(buildProfile(),true);});}return nav;
    }

    private void showQuickAdd() {
        Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout sheet=vbox();sheet.setBackground(bg(Color.WHITE,30));pad(sheet,24,18,24,26);TextView handle=tv("",1,Color.TRANSPARENT,false);handle.setBackground(bg(Color.rgb(203,213,225),4));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(54),dp(6));hp.gravity=Gravity.CENTER;sheet.addView(handle,hp);sheet.addView(space(18));sheet.addView(tv("Quick add",24,INK,true));sheet.addView(tv("Capture a task without losing your flow.",14,MUTED,false));sheet.addView(space(20));EditText input=new EditText(this);input.setHint("Write what you need to do…");input.setTextColor(INK);input.setHintTextColor(Color.rgb(148,163,184));input.setTextSize(15);input.setSingleLine(true);input.setBackground(bgStroke(CANVAS,16,Color.rgb(203,213,225)));pad(input,16,0,16,0);sheet.addView(input,new LinearLayout.LayoutParams(-1,dp(62)));sheet.addView(space(18));LinearLayout row=hbox();row.setGravity(Gravity.CENTER_VERTICAL);row.addView(tv("Schedule a focus block",15,INK,true),new LinearLayout.LayoutParams(0,dp(48),1));Switch sw=new Switch(this);sw.setChecked(true);row.addView(sw);sheet.addView(row);sheet.addView(space(16));Button add=button("Add task",PRIMARY,Color.WHITE);sheet.addView(add,new LinearLayout.LayoutParams(-1,dp(56)));TextView dismiss=tv("Dismiss",13,MUTED,true);dismiss.setGravity(Gravity.CENTER);sheet.addView(dismiss,new LinearLayout.LayoutParams(-1,dp(48)));d.setContentView(sheet);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(-1,-2);w.setGravity(Gravity.BOTTOM);w.setDimAmount(.35f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}add.setOnClickListener(v->{String task=input.getText().toString().trim();if(task.isEmpty()){input.setError("Add a task");return;}add.setText("Adding…");add.animate().scaleX(.96f).scaleY(.96f).setDuration(120).withEndAction(()->{prefs.edit().putString("extra",task).apply();add.setText("✓ Added");add.setBackground(bg(GREEN,18));add.postDelayed(()->{d.dismiss();replace(buildHome(),false);},650);}).start();});dismiss.setOnClickListener(v->d.dismiss());d.setOnShowListener(x->{Window ww=d.getWindow();if(ww!=null)ww.setLayout(-1,-2);sheet.setTranslationY(dp(300));sheet.animate().translationY(0).setDuration(360).setInterpolator(new DecelerateInterpolator()).start();});d.show();
    }

    private View buildTaskDetail(int n) {
        String task=prefs.getString("p"+n,n==2?"Review app prototype":"Priority");LinearLayout body=vbox();pad(body,24,28,24,28);body.setBackgroundColor(CANVAS);LinearLayout top=hbox();TextView back=tv("‹",34,INK,false);top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));Space x=new Space(this);top.addView(x,new LinearLayout.LayoutParams(0,1,1));top.addView(pill("Priority "+n,PALE_PURPLE,PRIMARY),new LinearLayout.LayoutParams(dp(112),dp(36)));body.addView(top);back.setOnClickListener(v->replace(buildHome(),false));body.addView(space(20));body.addView(tv(task,28,INK,true));body.addView(space(8));TextView desc=tv("Turn feedback into a clean UI revision before development continues.",14,MUTED,false);desc.setLineSpacing(dp(4),1);body.addView(desc);body.addView(space(36));LinearLayout stats=hbox();LinearLayout a=vbox();a.addView(tv("Focus estimate",12,MUTED,false));a.addView(tv("25 minutes",18,INK,true));LinearLayout b=vbox();b.addView(tv("Best window",12,MUTED,false));b.addView(tv("11:30 – 12:00",18,INK,true));stats.addView(a,new LinearLayout.LayoutParams(0,dp(60),1));stats.addView(b,new LinearLayout.LayoutParams(0,dp(60),1));body.addView(stats);body.addView(space(28));body.addView(tv("Checklist",15,INK,true));String[] items={"Review current screens","List 3 biggest UI problems","Approve new visual direction","Send changes to build"};for(int i=0;i<items.length;i++){CheckBox c=new CheckBox(this);c.setText(items[i]);c.setTextColor(INK);c.setTextSize(14);c.setButtonTintList(android.content.res.ColorStateList.valueOf(PRIMARY));c.setChecked(i==0);body.addView(c,new LinearLayout.LayoutParams(-1,dp(54)));}body.addView(space(34));Button start=button("Start focus session",PRIMARY,Color.WHITE);body.addView(start,new LinearLayout.LayoutParams(-1,dp(56)));start.setOnClickListener(v->startFocus());return shell(body);
    }

    private void startFocus() { remainingMs=25*60*1000L; timerRunning=false; replace(buildFocus(),true); startTimer(); }

    private View buildFocus() {
        LinearLayout body=vbox();focusScreen=body;pad(body,24,30,24,28);body.setBackgroundColor(CANVAS);TextView dnd=pill("DO NOT DISTURB",PALE_PURPLE,PRIMARY);LinearLayout.LayoutParams dnp=new LinearLayout.LayoutParams(dp(152),dp(36));dnp.gravity=Gravity.CENTER;body.addView(dnd,dnp);body.addView(space(28));TextView title=tv(prefs.getString("p2","Review app prototype"),23,INK,true);title.setGravity(Gravity.CENTER);body.addView(title,new LinearLayout.LayoutParams(-1,dp(42)));body.addView(space(38));circleTimerView=new CircleTimerView(this);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(170),dp(170));cp.gravity=Gravity.CENTER;body.addView(circleTimerView,cp);timerText=tv(formatTime(remainingMs),28,INK,true);timerText.setGravity(Gravity.CENTER);FrameLayout overlay=new FrameLayout(this);overlay.setVisibility(View.GONE);body.addView(space(24));body.addView(tv("Stay with one thing.",18,INK,true));body.getChildAt(body.getChildCount()-1).setTextAlignment(View.TEXT_ALIGNMENT_CENTER);TextView sub=tv("Everything else can wait.",13,MUTED,false);sub.setGravity(Gravity.CENTER);body.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));body.addView(space(40));LinearLayout controls=hbox();Button pause=button("Pause",Color.WHITE,INK);pause.setBackground(bgStroke(Color.WHITE,16,BORDER));Button finish=button("Finish",PRIMARY,Color.WHITE);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(52),1);bp.rightMargin=dp(6);controls.addView(pause,bp);LinearLayout.LayoutParams bf=new LinearLayout.LayoutParams(0,dp(52),1);bf.leftMargin=dp(6);controls.addView(finish,bf);body.addView(controls);body.addView(space(52));body.addView(tv("Ambient sound",13,INK,true));body.addView(space(10));LinearLayout sounds=hbox();String[] ss={"Rain","Brown noise","Off"};for(int i=0;i<3;i++){TextView p=pill(ss[i],i==0?PALE_PURPLE:Color.WHITE,i==0?PRIMARY:MUTED);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(38),1);if(i>0)pp.leftMargin=dp(8);sounds.addView(p,pp);}body.addView(sounds);pause.setOnClickListener(v->{if(timerRunning){pauseTimer();pause.setText("Resume");dnd.setText("PAUSED");dnd.animate().scaleX(1.08f).scaleY(1.08f).setDuration(160).withEndAction(()->dnd.animate().scaleX(1).scaleY(1).setDuration(160).start()).start();}else{startTimer();pause.setText("Pause");dnd.setText("DO NOT DISTURB");}});finish.setOnClickListener(v->completeFocus());return shell(body);
    }

    private void startTimer() {
        if(countDownTimer!=null) countDownTimer.cancel();timerRunning=true;countDownTimer=new CountDownTimer(remainingMs,1000){public void onTick(long ms){remainingMs=ms;if(timerText!=null)timerText.setText(formatTime(ms));if(circleTimerView!=null){circleTimerView.progress=(25*60*1000L-ms)/(float)(25*60*1000L);circleTimerView.invalidate();}}public void onFinish(){remainingMs=0;timerRunning=false;notifyFocusDone();completeFocus();}}.start();
    }
    private void pauseTimer(){if(countDownTimer!=null)countDownTimer.cancel();timerRunning=false;}
    private String formatTime(long ms){long sec=Math.max(0,ms/1000),m=sec/60,s=sec%60;return String.format(Locale.US,"%02d:%02d",m,s);}
    private void completeFocus(){pauseTimer();int mins=prefs.getInt("focusMinutes",0)+Math.max(1,(int)((25*60*1000L-remainingMs)/60000));prefs.edit().putInt("focusMinutes",mins).putInt("sessions",prefs.getInt("sessions",0)+1).putBoolean("done2",true).apply();replace(buildComplete(),true);}

    private View buildComplete(){FrameLayout wrap=new FrameLayout(this);LinearLayout body=vbox();pad(body,24,60,24,28);body.setGravity(Gravity.CENTER_HORIZONTAL);body.setBackgroundColor(CANVAS);TextView check=tv("✓",46,GREEN,true);check.setGravity(Gravity.CENTER);check.setBackground(bg(Color.rgb(220,252,231),50));body.addView(check,new LinearLayout.LayoutParams(dp(96),dp(96)));body.addView(space(26));TextView title=tv("Nice work.",29,INK,true);title.setGravity(Gravity.CENTER);body.addView(title);TextView sub=tv("You finished a full focus block.",14,MUTED,false);sub.setGravity(Gravity.CENTER);body.addView(sub);body.addView(space(44));LinearLayout stats=card();stats.setOrientation(LinearLayout.HORIZONTAL);stats.addView(stat("25 min","Focused"),new LinearLayout.LayoutParams(0,dp(92),1));stats.addView(stat("1","Task moved"),new LinearLayout.LayoutParams(0,dp(92),1));stats.addView(stat("0","Distractions"),new LinearLayout.LayoutParams(0,dp(92),1));body.addView(stats,new LinearLayout.LayoutParams(-1,dp(132)));body.addView(space(40));body.addView(tv("How did that feel?",14,INK,true));body.addView(space(12));LinearLayout moods=hbox();String[] mm={"Hard","Good","Easy"};for(int i=0;i<3;i++){TextView p=pill(mm[i],i==1?PRIMARY:Color.WHITE,i==1?Color.WHITE:MUTED);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(38),1);if(i>0)mp.leftMargin=dp(10);moods.addView(p,mp);final String mood=mm[i];p.setOnClickListener(v->prefs.edit().putString("lastFocusMood",mood).apply());}body.addView(moods);body.addView(space(50));Button cont=button("Continue my day",PRIMARY,Color.WHITE);body.addView(cont,new LinearLayout.LayoutParams(-1,dp(56)));cont.setOnClickListener(v->replace(buildHome(),true));wrap.addView(shell(body),new FrameLayout.LayoutParams(-1,-1));ConfettiView cf=new ConfettiView(this);wrap.addView(cf,new FrameLayout.LayoutParams(-1,-1));cf.start();return wrap;}
    private LinearLayout stat(String n,String label){LinearLayout l=vbox();l.setGravity(Gravity.CENTER);TextView a=tv(n,22,INK,true);a.setGravity(Gravity.CENTER);TextView b=tv(label,11,MUTED,false);b.setGravity(Gravity.CENTER);l.addView(a);l.addView(b);return l;}

    private View buildReflection(){LinearLayout body=vbox();pad(body,24,30,24,28);body.setBackgroundColor(CANVAS);body.addView(tv("Close the day",28,INK,true));body.addView(tv("Two minutes now, less mental clutter tomorrow.",14,MUTED,false));body.addView(space(34));body.addView(tv("Today felt…",14,INK,true));body.addView(space(12));LinearLayout moods=hbox();String[] ms={"Heavy","Balanced","Great"};final String[] selected={prefs.getString("dayMood","Balanced")};for(int i=0;i<3;i++){TextView p=pill(ms[i],ms[i].equals(selected[0])?PRIMARY:Color.WHITE,ms[i].equals(selected[0])?Color.WHITE:MUTED);LinearLayout.LayoutParams m=new LinearLayout.LayoutParams(0,dp(38),1);if(i>0)m.leftMargin=dp(10);moods.addView(p,m);final String val=ms[i];p.setOnClickListener(v->{selected[0]=val;Toast.makeText(this,val,Toast.LENGTH_SHORT).show();});}body.addView(moods);body.addView(space(28));body.addView(tv("What went well?",14,INK,true));body.addView(space(10));EditText note=new EditText(this);note.setHint("I stayed focused on the important work…");note.setText(prefs.getString("reflection",""));note.setTextSize(14);note.setTextColor(INK);note.setHintTextColor(Color.rgb(148,163,184));note.setGravity(Gravity.TOP);note.setBackground(bgStroke(Color.WHITE,18,BORDER));pad(note,16,14,16,14);body.addView(note,new LinearLayout.LayoutParams(-1,dp(110)));body.addView(space(28));body.addView(tv("Move to tomorrow",14,INK,true));LinearLayout move=card();move.setOrientation(LinearLayout.HORIZONTAL);move.setGravity(Gravity.CENTER_VERTICAL);CheckBox cb=new CheckBox(this);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(PRIMARY));move.addView(cb,new LinearLayout.LayoutParams(dp(42),dp(42)));move.addView(tv(prefs.getString("p3","30 min exercise"),14,INK,true),new LinearLayout.LayoutParams(0,dp(42),1));move.addView(tv("Tomorrow",12,MUTED,false),new LinearLayout.LayoutParams(dp(72),dp(42)));body.addView(move,new LinearLayout.LayoutParams(-1,dp(72)));body.addView(space(52));Button close=button("Close today",PRIMARY,Color.WHITE);body.addView(close,new LinearLayout.LayoutParams(-1,dp(56)));close.setOnClickListener(v->{prefs.edit().putString("dayMood",selected[0]).putString("reflection",note.getText().toString()).putInt("daysClosed",prefs.getInt("daysClosed",0)+1).apply();replace(buildInsights(),true);});body.addView(space(28));body.addView(bottomNav(3),new LinearLayout.LayoutParams(-1,dp(72)));return shell(body);}

    private View buildInsights(){LinearLayout body=vbox();pad(body,24,30,24,20);body.setBackgroundColor(CANVAS);body.addView(tv("Your rhythm",28,INK,true));body.addView(tv("Patterns from your recent focus sessions",13,MUTED,false));body.addView(space(28));LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);int sessions=prefs.getInt("sessions",0);int days=Math.max(1,prefs.getInt("daysClosed",1));int consistency=Math.min(100,65+sessions*7);LinearLayout left=vbox();left.addView(tv("Consistency",12,MUTED,false));left.addView(tv(consistency+"%",31,INK,true));left.addView(tv("↑ building momentum",11,GREEN,true));LinearLayout right=vbox();right.addView(tv("Best focus window",12,MUTED,false));right.addView(tv("10–12 AM",19,INK,true));c.addView(left,new LinearLayout.LayoutParams(0,dp(100),1));c.addView(right,new LinearLayout.LayoutParams(0,dp(100),1));body.addView(c,new LinearLayout.LayoutParams(-1,dp(142)));body.addView(space(28));body.addView(tv("Focus minutes",14,INK,true));body.addView(space(10));MiniBarsView chart=new MiniBarsView(this);chart.total=prefs.getInt("focusMinutes",0);chart.setBackground(bgStroke(Color.WHITE,20,BORDER));body.addView(chart,new LinearLayout.LayoutParams(-1,dp(190)));body.addView(space(28));LinearLayout insight=card();insight.addView(tv("Small insight",12,MUTED,false));insight.addView(tv(sessions==0?"Start one focus session and PocketPilot will begin learning your rhythm.":"You’re more consistent when you protect a single uninterrupted block.",14,INK,true));body.addView(insight,new LinearLayout.LayoutParams(-1,dp(90)));body.addView(space(46));body.addView(bottomNav(0),new LinearLayout.LayoutParams(-1,dp(72)));return shell(body);}

    private View buildTasks(){LinearLayout body=vbox();pad(body,24,30,24,20);body.setBackgroundColor(CANVAS);body.addView(tv("Tasks",28,INK,true));body.addView(tv("Tap a priority to mark it complete.",13,MUTED,false));body.addView(space(28));for(int n=1;n<=3;n++){final int idx=n;CheckBox c=new CheckBox(this);c.setText(prefs.getString("p"+n,"Priority "+n));c.setChecked(prefs.getBoolean("done"+n,n==1));c.setTextSize(15);c.setTextColor(INK);c.setButtonTintList(android.content.res.ColorStateList.valueOf(PRIMARY));c.setBackground(bgStroke(Color.WHITE,18,BORDER));pad(c,16,8,16,8);body.addView(c,new LinearLayout.LayoutParams(-1,dp(64)));body.addView(space(10));c.setOnCheckedChangeListener((b,x)->prefs.edit().putBoolean("done"+idx,x).apply());}String ex=prefs.getString("extra","");if(!ex.isEmpty()){CheckBox c=new CheckBox(this);c.setText(ex);c.setTextColor(INK);c.setTextSize(15);c.setBackground(bgStroke(Color.WHITE,18,BORDER));pad(c,16,8,16,8);body.addView(c,new LinearLayout.LayoutParams(-1,dp(64)));}body.addView(space(30));Button setup=button("Edit today’s priorities",PRIMARY,Color.WHITE);body.addView(setup,new LinearLayout.LayoutParams(-1,dp(54)));setup.setOnClickListener(v->replace(buildDailySetup(),true));body.addView(space(40));body.addView(bottomNav(1),new LinearLayout.LayoutParams(-1,dp(72)));return shell(body);}

    private View buildProfile(){LinearLayout body=vbox();pad(body,24,30,24,20);body.setBackgroundColor(CANVAS);body.addView(tv("PocketPilot",28,INK,true));body.addView(tv("Local-first personal focus companion",13,MUTED,false));body.addView(space(30));LinearLayout stats=card();stats.addView(tv("On this phone",12,MUTED,false));stats.addView(space(8));stats.addView(tv(prefs.getInt("sessions",0)+" focus sessions",20,INK,true));stats.addView(tv(prefs.getInt("focusMinutes",0)+" focused minutes",14,MUTED,false));body.addView(stats,new LinearLayout.LayoutParams(-1,dp(130)));body.addView(space(18));LinearLayout privacy=card();privacy.addView(tv("Privacy",14,INK,true));privacy.addView(space(6));TextView copy=tv("PocketPilot stores your tasks, reflections, and stats locally on this device. No sign-in and no cloud account are required.",13,MUTED,false);copy.setLineSpacing(dp(4),1);privacy.addView(copy);body.addView(privacy,new LinearLayout.LayoutParams(-1,dp(140)));body.addView(space(24));Button reset=button("Reset onboarding",Color.WHITE,PRIMARY);reset.setBackground(bgStroke(Color.WHITE,18,BORDER));body.addView(reset,new LinearLayout.LayoutParams(-1,dp(52)));reset.setOnClickListener(v->{prefs.edit().putBoolean("onboarded",false).apply();Toast.makeText(this,"Onboarding will show next launch",Toast.LENGTH_SHORT).show();});body.addView(space(40));body.addView(bottomNav(3),new LinearLayout.LayoutParams(-1,dp(72)));return shell(body);}

    private int completedCount(){int c=0;for(int i=1;i<=3;i++)if(prefs.getBoolean("done"+i,i==1))c++;return c;}

    private void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHAOOEL));Butt44)hannel());body.addView(move,new LiCHAO{.Te(bg(CouDEbLiCHAO{;i<3;i++){TextView p=pill(ms[i],ms[i].equals(selected[0])?PRIMARY:Color.WHITE,ms[i].equals(selected[0])?Col,Color.We(bg(CouDEbLiCHAO{;i<3;i++){TeO{;i<3;i++){TextVi,",0)+,INK,t)eS);Texo(+,INK,2>{prefs.edit().putBoolgetString{TextVi,",0)+,INK,t gsYvoid earLayout.LayoutPaickL5k7MTDAdWe(b_ES�TDE  )HITE,ms[i].equals(selected ck=tv("cketPted ck=tv("cketPted ck=tv("cketPted ck=tv("ckLayoutPaick)d();pause.seeeeeeeeeeeeeeeee;kVckgrouEions",20,,,,,,�b   vyoudView(tv("10–12 AM"ouEions",20,,,,,,�b   vyoudView(tv("10–12 AM"ouEions",20,,,,,,�b   vyoudView(tv("10–12 AM"ouEions",20,,,,,,�b   vyoudView(tv("10–12 AM"ouEions",20,,,,,,�b   vyoudView(tv("10–12 AM"ouEions",20,,,,,,�b   vyoudView(tv("10–12 AM"ouEions",20,,,,,,�b   vcusMinuL",0)+,INK_ ,,,,,�b   vcusMinuL",0)+,INK_ ,,,,,�b   vcusMinuL",0)+,INK_ ,,,,,�b   vcusMinuL"ref  OOOOOOOOOOTintFNT_,,�bb%SAOp=neahtOOOOOOOTintFNT_,,�bb%SAOp=neahtOOOOOOOTin71M= this dintFNT_,,�bb%}"::;Toast.makeText(this,cted ck=tv("cketPted ck=tv10�View(reset,new Linea+,INK_ ,,,,,�b   vcusMinuL"n go=button("K_ ,,,,ew buildProD      return s)oiddv(label,.0outPaickL5k7MTan("kPte,1f12 AM"ouEions",2R));ismissclose.setOnClicns",2adddddddac,new LiyoudVi-OnClicns",2ap(40)aNkgr{final int idx0=Kn;CheckB23 priorities",23,Color.WHITE,tgLDUS",23,COdy.ade,184)?PRIMARY:Color.WHnmissclose.setOnClicns",2adddddddac,new LiyoudVi-On[0]tLinea!nt iOnClicns",2adddddddac,new LiyoudVi-On[0]tLinea!nt iOnClicns",2adddddddac,new LiyoudVi-On[0]tLinea!nt iOnClicns",2adddddddac,new LiyoudVi-On[0]tLinea!nt iOnClicns",2adddddddac,new LiyoudVi-On[0]tLinea!nt iOnClicns",2adddddddac,new LiyoudVi-On[0]tLinea!nt iOnCrefc=,dp(72)));return shell(body);}

dVi-On[0]tLinea!nt9=Pddddac,new LiyoduEiovity.CENTEd(bgStClicns",2aSmickLeAtn voia4.Layouiew(tv("Your rhythm",2r+,INK_ ,,,,,�bms(davi20,,)extView back=ttttttc,new LiyolxtView  LiyoudViW=.View(rea,INKattti=ew(space(30)",2adddiconChaeplaceackLis.addView(s 2)",2k=tv( 7"h)k it tColor(IN ew Line3ea,INKattti=ew(space(30)",2adddiconChaeplaceackLis.addView(s 2)",2k=tv( 7"h)k it tColor(IN ew Line3ea,INKattti=ew(space(30)",2adddiconChaeplaceackLis.addView(s 2)",2k=tv( 7"h)k it tColor(IN ew Line3ea,INKattti=ew(space(30)",2adddiconChaeplaceackLis.addView(sfalse);1vice. Nats,nimere.l()){;bodtdddddac,istener(v->000L-ms)/(float)(25Np((floatL-ms)/?ims)/Ot_oatL-ms)/?ims25Np((floatL-ms)/?iue. Nw Not,l()ttil{.T.HORIZNd(bo);sub.se);close.setBackground(bgStroke(Color.WHITE,18,BORDER));body.addView(close,new LinearLayout.LayoutParams(-1,dp(48)))@1d LinearLayE1d LinearLayE1d Log()).putInt("daysClosed",prefs.g= sWtm'.setOnCs;;raearLa6COdy..nogStd/cTfs.g= sWtm'.setOnCs;;raearLa6COdy..nogStd/cTfs.g= sWtm'.setOnCs;;raearLa6COdy..nogStd/cTfs.g= sWtm'.setOnCs;;raearLa6COdy..nogStd/cTfs.g= sWtm'.setOnCs;;raearLa6COdy..nogStd/cTfs.g= sWtm'.setOnCs;;raearLa6COdy..nogStd/cTfs.g= sWtm'.setOnCs;;raearLa6COdy..nogr.earLa6COdy..nogStd/cim"fCs;;rae(fll ingStdw(bottomNav(0),new.nogStd/cTfs.g= sWNx0.YESbdYREb_PMdGASE"0.YESbutParafs.g=_2)iE"0.YESbutParafs.g=ramfh)Wtm'.amfh)Wtm )Wtm'.amfh)Wt1lengStdw(bottomNav(0),new.nogSt_ebottnCs;;raeaA1m"tPi.g= s;;raeaA1m"tPi.g= s;;raeaA1m"tPi.g= s;;raeaA1m"tPi.g= s;;raeaA1messions",13,MUAyour rcy.a(i>0)mp..n/ ayoutP close=button("Close today",PRIMARY,Color.WHITIMARYspace(40));b/_dSP]Ec,new Lisa",PRinthaeplaceackLirn=iaeplacetTextAli=aeplace+f);bodcet();left.addView(tv(" hepl;}

    p{,out.L());}"leftainthaeplaceackLirn=ia2ieackLirn=iaNnearLayoy..nogStd/cTf, tation(LinearLayout.HORIZONTAL);RIZONTstats=card();stats.setOrientat c5+sessions*7);LinearLayout left=vbox();left.asOdy..nogStd/ci,i=}i.g= sn("Cloainthrientat c5 "ts,naxns",1,s,naxns",1,Links 2)",2k=tv( 7Ahe imporc,new.seTA5�Ody..utParami++){TextView p=pillaientat c5 "ts,naxns",1,s,naxns",1,Linksa13,Mfffffs..utinksa13,MWtm )Wtm'.te",12,MUTEcyg[] selecte 8(body,24,30,24,20);body.setBacutton("Cnthri,s,naxns"0ent�,,,,==niBarsVieitop);back"mat s;;raeaA1m"tPi.g= s;;raeaA1m"tPi.g= s;;raeaA1m"tPi.g= s;;raeaA1messions",13,MUAyour rcy.a(i>0)mp..n/ ayoutP close=butt